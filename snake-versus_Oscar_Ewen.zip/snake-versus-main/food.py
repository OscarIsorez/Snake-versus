import random
class Pomme():
    def __init__(self):
        self.pos = [random.randrange(0, 72), random.randrange(0, 48)]